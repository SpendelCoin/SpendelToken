# SpendelToken ($SPNDL)

SpendelToken is a meme-based ERC-20 token on the Base network.

### ✅ Contract Source Code

This contract is open-source and viewable here in full. Due to current limitations, Base’s block explorer (Blockscout) does not support source code verification manually or via Sourcify.

As soon as full verification becomes possible on Blockscout or Sourcify for chain ID 8453, it will be completed.

### 🛠 Details

- Name: Spendel
- Symbol: SPNDL
- Total Supply: 8,888,888,888
- Deployed to Base Chain
- Contract: `0x8e0bb447d07207F62d2c014981239D98d9D0848b`

---

### Files Included

- `SpendelToken.sol` — full flattened source code
- `metadata.json` — Solidity compilation metadata
